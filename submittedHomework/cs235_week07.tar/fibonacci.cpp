/***********************************************************************
 * Implementation:
 *    FIBONACCI
 * Summary:
 *    This will contain the implementation for fibonacci() as well as any
 *    other function or class implementations you may need
 * Author
 *    Adam Shumway, Jenaca Willans
 **********************************************************************/

#include <iostream>
#include "fibonacci.h"   // for fibonacci() prototype
#include "list.h"        // for LIST
using namespace std;


/************************************************
 * FIBONACCI
 * The interactive function allowing the user to
 * display Fibonacci numbers
 ***********************************************/
void fibonacci()
{
   // show the first serveral Fibonacci numbers
   int number;
   cout << "How many Fibonacci numbers would you like to see? ";
   cin  >> number;

   // your code to display the first <number> Fibonacci numbers
   int prev = 0;
   int curr = 1;
   int next = 0;

   cout << "\t" << curr << endl;

   for (int i = 0; i < number - 1; i++)
   {
      if (number == 1)
      {
         next = number;
      }
      else
      {
         next = prev + curr;
         prev = curr;
         curr = next;
      }
      
      cout << "\t" << next << endl;
   }
   
   // prompt for a single large Fibonacci
   cout << "Which Fibonacci number would you like to display? ";
   cin  >> number;

   // your code to display the <number>th Fibonacci number
   List<int> currList;
   List<int> nextList;

   currList.push_back(1);
   List<int> prevList(currList);

   int carry = 0;
   int sumBack = 0;

   for (int i = 0; i < number - 2; i++)
   {
      
      nextList.clear();
      
      for(ListIterator <int> cit = currList.rbegin();
          cit != currList.rend(); --cit)
         for(ListIterator <int> pit = prevList.rbegin();
             pit != prevList.rend(); --pit)
         {

               sumBack = (((*cit + *pit) % 1000) + carry);
               carry = (((*cit + *pit) - sumBack) / 1000);
               
               nextList.push_front(sumBack);
               sumBack = 0;
            
               if(carry >= 1 && pit == prevList.rbegin())
               {
                  nextList.push_front(carry);
                  carry = 0;
                  
                  if(prevList.size() != nextList.size())
                     currList.push_front(0);
               }

               prevList.clear();
               prevList = currList;
               
               currList.clear();
               currList = nextList;
               

         }

//      for(ListIterator <int> it = prevList.begin();
      //                      it != prevList.end(); ++it)
      //{
      //if(*it != prevList.back())
      //{
      //  cout << *it << ",";
      //}
      //else
      //{
      //  cout << *it << endl;
      //}
      //}
      //for(ListIterator <int> it = currList.begin();
      //  it != currList.end(); ++it)
      //{
      // if(*it != currList.back())
      // {
      //    cout << *it << ",";
      // }
      // else
      // {
      //    cout << *it << endl;
      // }
      //}

      
   }   
   
   // display List for nth Fibonacci number
   cout << "\t";

   for(ListIterator <int> it = nextList.begin();
       it != nextList.end(); ++it)
   {
      if(*it != nextList.back())
      {
         cout << *it << ",";
      }
      else
      {
         cout << *it << endl;
      }
   }
   
}


