/***********************************************************************
 * Implementation:
 *    STOCK
 * Summary:
 *    This will contain the implementation for stocksBuySell() as well
 *    as any other function or class implementation you need
 * Author
 *    Adam Shumway, Jenaca Willans
 **********************************************************************/

#include <iostream>    // for ISTREAM, OSTREAM, CIN, and COUT
#include <string>      // for STRING
#include <sstream>     // for STRING STREAM
#include "stock.h"     // for STOCK_TRANSACTION
#include "queue.h"     // for QUEUE
using namespace std;

/************************************************
 * STOCKS BUY SELL
 * The interactive function allowing the user to
 * buy and sell stocks
 ***********************************************/
void stocksBuySell()
{
   // instructions
   cout << "This program will allow you to buy and sell stocks. "
        << "The actions are:\n";
   cout << "  buy 200 $1.57   - Buy 200 shares at $1.57\n";
   cout << "  sell 150 $2.15  - Sell 150 shares at $2.15\n";
   cout << "  display         - Display your current stock portfolio\n";
   cout << "  quit            - Display a final report and quit the program\n";
   
   // your code here...
   // declare variables and Queues
   string choice;                  // buy/sell/display/quit
   int quantity;                   // how many stocks are bought or sold
   Queue <int> buyQueue;           // queue to hold quantity bought
   Dollars price;                  // price stock was bought or sold at
   Queue <Dollars> buyPriceQueue;  // queue to hold purchace price
   Queue <int> sellQueue;          // queue to hold quantity sold
   Queue <Dollars> sellPriceQueue; // queue to hold sell price
   Queue <Dollars> portfolio;      //holds profit/loss
   int buyTran = 0;                //buy transaction counter
   int sellTran = 0;               //sell transaction counter
   
   do
   {
      cout << "> ";
      cin >> choice;
      
      if (choice == "buy")
      {
         // read in purchase quanity and price
         // and push to respective queue
         cin >> quantity >> price;
         buyQueue.push(quantity);
         buyPriceQueue.push(price);

         // this is a buy transaction. Increment counter.
         buyTran++;
      }
      else if (choice == "sell")
      {
         // working queue for sell transactions
         Queue <int> wrkQ;
         Queue <Dollars> wrkP;

         // read in sell quantity and price
         // and push to respective queue
         cin >> quantity >> price;
         wrkQ.push(quantity);
         wrkP.push(price);

         // this is a sell transaction. Increment counter.
         sellTran++;

         // variables to hold current shares bought and sold.
         int sellShares = 0;
         int buyShares = 0;

         // set number of shares sold in upcoming transaction
         sellShares = wrkQ.front();
         
         //calculate proceeds with each sell transaction
         while (sellShares != buyShares)
         {
            // pull first buy and sell quantities from queues
            buyShares = buyQueue.front(); //get share count
            sellShares = wrkQ.front();
            Dollars proceeds = 0; 

            // if sell only uses a portion of one buy batch
            if(sellShares < buyShares)
            {
               int tempFront = buyQueue.getMyFront(); //get current position
               int tempBack = buyQueue.getMyBack();

               // calculate proceeds from batch
               proceeds = (wrkP.front() - buyPriceQueue.front()) * sellShares;
               
               //move items from workQ to sell and price queues
               sellQueue.push(wrkQ.front());
               sellPriceQueue.push(wrkP.front());
               wrkQ.pop();
               wrkP.pop();
               
               //set buy queues properly
               buyQueue.pop();
               buyQueue.setMyBack(tempFront);
               buyShares -= sellShares;
               buyQueue.push(buyShares); //push new share count
               buyQueue.setMyFront(tempFront);
               buyQueue.setMyBack(tempBack);
               buyShares = sellShares;  //setting the same to break the loops
               portfolio.push(proceeds); //push proceeds of sale to port queue
            }
            // if sell uses exactly one buy batch
            else if (sellShares == buyShares)
            {
               //assuming multiple iterations, adding
               //proceeds to itself and result of math
               proceeds = (wrkP.front() - buyPriceQueue.front()) * sellShares;
               sellQueue.push(wrkQ.front());
               sellPriceQueue.push(wrkP.front());
               wrkQ.pop();
               wrkP.pop();
               buyQueue.pop();       //pop all purchased shares at this price
               buyPriceQueue.pop();    //pop all share prices at this quantity
               buyShares = sellShares;  //setting the same to break the loops
               portfolio.push(proceeds); //push proceeds of sale to port queue
               buyTran--;
            }
            // if sell will use more than one buy batch
            else
            {
               int tempFront = wrkQ.getMyFront(); //get current position
               int tempBack = wrkQ.getMyBack();
               //assuming multiple iterations, adding
               //proceeds to itself and result of math
               //using buy shares until sellshares are less than buyshares
               proceeds = (wrkP.front() - buyPriceQueue.front()) * buyShares;
               buyQueue.pop();       //pop all purchased shares at this price
               buyPriceQueue.pop();    //pop all share prices at this quantity
               portfolio.push(proceeds); //push proceeds of sale to port queue
               sellShares -= buyShares; //decrement sellShares by buyShare amt
               sellQueue.push(buyShares);
               sellPriceQueue.push(wrkP.front());
               wrkQ.pop();
               wrkQ.setMyBack(tempFront);
               wrkQ.push(sellShares);
               wrkQ.setMyFront(tempFront);
               wrkQ.setMyBack(tempBack);
               buyTran--;
               sellTran++;
            }
         }
      }
      else if (choice == "display")
      {
         Dollars portSum = 0; //for use with the proceeds (portfolio summary)

         // make copies of current queue data
         Queue <int> bQ(buyQueue); //buyQueue
         Queue <Dollars> bP(buyPriceQueue); //buyPriceQueue
         Queue <int> sQ(sellQueue); //sellQueue
         Queue <Dollars> sP(sellPriceQueue); //sellPriceQueue
         Queue <Dollars> pList(portfolio); //portfolio queue
         
         // if there are buy transactions remaining, output holdings
         if (buyTran > 0)
         {
            cout << "Currently held:\n";
            for (int i = 0; i < buyTran; i++)
            {
               cout << "\tBought " << bQ.front()
                    << " shares at " << bP.front()
                    << endl;
               bQ.pop();
               bP.pop();
            }
         }
         
         // if there has been a sale, output sell history
         if (sellTran > 0)
         {
            cout << "Sell History:\n";
            for (int i = 0; i < sellTran; i++)
            {
               cout << "\tSold " << sQ.front()
                    << " shares at " << sP.front()
                    << " for a profit of " << pList.front() << endl; 
               portSum += pList.front();
               sQ.pop();
               sP.pop();
               pList.pop();
            }
         }
         
         //display proceeds
         cout << "Proceeds: "; 
         if (portfolio.empty())
         {
            cout << "$0.00\n";
         }
         else
         {
            cout << portSum << endl;
         }
         
      }
   }
   while (choice != "quit");
    
}
